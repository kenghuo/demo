import React, { Component } from 'react';

import Demo from '../component/demo';

class App extends Component {
  render() {
    return (
        <Demo />
    );
  }
}

export default App;
