import { combineReducers } from 'redux';

import title from './title.js';

export default combineReducers({
    title
});