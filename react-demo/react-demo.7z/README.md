当前脚手架基于 create-react-app,  
该脚手架已引用 bootstrap 以及 reactstrap
添加依赖 redux redux-thunk react-redux react-logger react-router

## 运行项目

```
$ npm install

$ npm start
```

项目中加入 redux 以及 route 内容

reduxs 目录下存放 reducer 文件

component 目录下存放 react 组件

router 目录下存放 route 文件